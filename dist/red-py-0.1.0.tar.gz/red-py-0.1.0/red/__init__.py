"""
red-py

A library of useful tools and extensions!
"""

__version__ = "0.1.0"
__author__  = "Zeeshan Hooda"
__credits__ = "Inara Lalani, John Aycock"